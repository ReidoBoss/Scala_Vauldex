package Printer:
	def pln(s:Any="") =
		println(Console.YELLOW+s+Console.RESET)
	def p(s:Any="") =
		print(Console.YELLOW+s+Console.RESET)